const Validator = require("validator");
const isEmpty = require("./is-empty");

module.exports = function validateUserInput(data) {
  let errors = {};

  data.name = !isEmpty(data.name) ? data.name : "";
  data.email = !isEmpty(data.email) ? data.email : "";
  data.phone = !isEmpty(data.phone) ? data.phone : "";
  data.address = !isEmpty(data.address) ? data.address : "";
  data.basic_salary = !isEmpty(data.basic_salary) ? data.basic_salary : "";
  data.bonus = !isEmpty(data.bonus) ? data.bonus : "";

  if (Validator.isEmpty(data.name)) {
    errors.name = "Name is required";
  }

  if (Validator.isEmpty(data.phone)) {
    errors.phone = "Phone is required";
  } else if (!Validator.isNumeric(data.phone)) {
    errors.phone = "Not a valid number";
  }

  if (Validator.isEmpty(data.basic_salary)) {
    errors.basic_salary = "basic salary is required";
  } else if (!Validator.isNumeric(data.basic_salary)) {
    errors.basic_salary = "basic salary is not a valid number";
  }

  if (!Validator.isEmpty(data.bonus)) {
    if (!Validator.isNumeric(data.bonus)) {
      errors.bonus = "bonus is not a valid number";
    }
  }

  if (Validator.isEmpty(data.email)) {
    errors.email = "Email is required";
  } else if (!Validator.isEmail(data.email)) {
    errors.email = "Not a valid email";
  }

  if (Validator.isEmpty(data.address)) {
    errors.address = "Address is required";
  }

  return {
    errors,
  };
};
