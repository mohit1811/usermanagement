const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Create Schema
const SalarySchema = new Schema({
  user_id: {
    type: Schema.Types.ObjectId,
    ref: "User",
  },
  basic_salary: {
    type: Number,
    required: true,
  },
  bonus: {
    type: Number,
    required: true,
  },
});

module.exports = Salary = mongoose.model("Salary", SalarySchema, "salaries");
