export const adduser = (data) => {
  return {
    type: "addUser",
    payload: {
      _id: data._id,
      name: data.name,
      date: data.date,
      role: data.role,
      status: data.status,
      email: data.email,
      phone: data.phone,
      address: data.address,
      gender: data.gender,
      photo: data.photo,
    },
  };
};

export const edituser = (data) => {
  return {
    type: "editUser",
    payload: {
      _id: data._id,
      name: data.name,
      date: data.date,
      role: data.role,
      status: data.status,
      email: data.email,
      phone: data.phone,
      address: data.address,
      gender: data.gender,
      photo: data.photo,
    },
  };
};

export const deleteuser = (data) => {
  return {
    type: "deleteUser",
    payload: {
      _id: data,
    },
  };
};

export const updateAppState = (data) => {
  return {
    type: "updateAppState",
    payload: data,
  };
};
