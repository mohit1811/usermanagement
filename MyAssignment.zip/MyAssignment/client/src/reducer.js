const initialState = {
  users: [],
};
const reducer = (state = initialState, action) => {
  switch (action.type) {
    case "addUser":
      const newUser = {
        _id: action.payload._id,
        name: action.payload.name,
        date: action.payload.date,
        role: action.payload.role,
        status: action.payload.status,
        email: action.payload.email,
        phone: action.payload.phone,
        address: action.payload.address,
        gender: action.payload.gender,
        photo: action.payload.photo,
      };
      return {
        ...state,
        users: [...state.users, newUser],
      };

    case "updateAppState":
      const newArr = action.payload.map((row, index) => ({
        _id: row._id,
        name: row.name,
        date: row.date,
        role: row.role,
        status: row.status,
        email: row.email,
        phone: row.phone,
        address: row.address,
        gender: row.gender,
        photo: row.photo,
        salary: row.salary,
      }));

      return {
        ...state,
        users: [...state.users, ...newArr],
      };

    case "editUser":
      const index = state.users.findIndex(
        (obj) => obj._id === action.payload._id
      );
      const editUser = {
        _id: action.payload._id,
        name: action.payload.name,
        date: action.payload.date,
        role: action.payload.role,
        status: action.payload.status,
        email: action.payload.email,
        phone: action.payload.phone,
        address: action.payload.address,
        gender: action.payload.gender,
        photo: action.payload.photo,
      };
      console.log(editUser);
      return {
        ...state,
        users: [
          ...state.users.splice(0, index),
          editUser,
          ...state.users.splice(index + 1),
        ],
      };

    case "deleteUser":
      return {
        users: [
          ...state.users.filter((user) => user._id !== action.payload._id),
        ],
      };

    default:
      return state;
  }
};
export default reducer;
