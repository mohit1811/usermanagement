import React from "react";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import { useSelector, useDispatch } from "react-redux";
import { Button } from "react-bootstrap";
import axios from "axios";
import { updateAppState } from "../action";

const MainTable = (props) => {
  const dispatch = useDispatch();
  const store = useSelector((store) => {
    return store;
  });

  if (store.users.length == 0) {
    axios
      .get("http://localhost:5000/api/user") // where the api gets fetched
      .then((res) => {
        dispatch(updateAppState(res.data));
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const dataArra = store.users.map((user) => ({
    image: "http://localhost:5000/uploads/" + user.photo,
    ...user,
  }));

  const imageFormatter = (cell, row) => {
    return (
      <span>
        <img src={cell} style={{ width: 50 }} />
        {row.name}
      </span>
    );
  };

  const buttonGroup = (cell, row) => {
    return (
      <span>
        <Button
          variant="info"
          className="mr-2"
          onClick={() => props.populateEditForm(row._id)}
        >
          Edit
        </Button>
        <Button variant="danger" onClick={() => props.deleteHandler(row._id)}>
          Delete
        </Button>
      </span>
    );
  };

  const columns = [
    { dataField: "_id", text: "Id", sort: true },
    { dataField: "image", text: "Name", sort: true, formatter: imageFormatter },
    { dataField: "date", text: "Date Created", sort: true },
    { dataField: "role", text: "Role" },
    { dataField: "status", text: "Status" },
    { dataField: "action", text: "Action", formatter: buttonGroup },
  ];

  const defaultSorted = [
    {
      dataField: "name",
      order: "desc",
    },
  ];

  const pagination = paginationFactory({
    page: 1,
    sizePerPage: 5,
    lastPageText: ">>",
    firstPageText: "<<",
    nextPageText: ">",
    prePageText: "<",
    showTotal: true,
    alwaysShowAllBtns: true,
    onPageChange: function (page, sizePerPage) {
      console.log("page", page);
      console.log("sizePerPage", sizePerPage);
    },
    onSizePerPageChange: function (page, sizePerPage) {
      console.log("page", page);
      console.log("sizePerPage", sizePerPage);
    },
  });

  return (
    <div className="App">
      <BootstrapTable
        bootstrap4
        keyField="_id"
        data={dataArra}
        columns={columns}
        defaultSorted={defaultSorted}
        pagination={pagination}
      />
    </div>
  );
};

export default MainTable;
