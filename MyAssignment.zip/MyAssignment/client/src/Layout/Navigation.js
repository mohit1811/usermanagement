import React from "react";
import { Navbar, Button } from "react-bootstrap";
import { CSVLink } from "react-csv";

const Navigation = (props) => {
  const csvData = [["Name", "Email", "Gender", "Role", "Address", "Status"]];
  props.csvData.users.map((user) => {
    csvData.push([
      user.name,
      user.email,
      user.gender,
      user.role,
      user.address,
      user.status,
    ]);
  });

  console.log("mohit----");
  console.log(csvData);
  return (
    <Navbar bg="primary" variant="dark">
      <Navbar.Brand href="#home" className="mr-auto">
        User Management
      </Navbar.Brand>
      <CSVLink data={csvData}>
        <Button className="mr-sm-2" variant="light">
          Export to Excel
        </Button>
      </CSVLink>{" "}
      <Button variant="light" onClick={() => props.changeState()}>
        Add New User
      </Button>
    </Navbar>
  );
};

export default Navigation;
