import React, { useState } from "react";
import { Form, Col, Button, Modal } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { adduser } from "../action";
import Navigation from "./Navigation";
import MainTable from "./MainTable";
import { deleteuser, edituser } from "../action";

const MainContainer = () => {
  const store = useSelector((store) => {
    return store;
  });

  const initialFormData = {
    _id: "",
    name: "",
    email: "",
    phone: "",
    address: "",
    gender: "Male",
    status: "Active",
    role: "Admin",
    basic_salary: "",
    bonus: "",
    salary: "",
  };
  const dispatch = useDispatch();
  const [selectedFile, setSelectedFile] = useState(null);
  const [formData, updateFormData] = useState({
    _id: "",
    name: "",
    email: "",
    phone: "",
    address: "",
    gender: "Male",
    status: "Active",
    role: "Admin",
    basic_salary: "",
    bonus: "",
    salary: "",
  });

  const [modalstate, setState] = useState(false);
  const changeState = () => {
    updateFormData({ ...initialFormData });
    setState(!modalstate);
  };

  const populateEditForm = (record_id) => {
    axios
      .get("http://localhost:5000/api/user/edit/" + record_id)
      .then((res) => {
        updateFormData({
          ...res.data,
          basic_salary: res.data.salary.basic_salary,
          bonus: res.data.salary.bonus,
        });
        setState(!modalstate);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const deleteHandler = (record_id) => {
    axios
      .delete("http://localhost:5000/api/user/delete/" + record_id)
      .then((res) => {
        if (res.data.success) {
          dispatch(deleteuser(record_id));
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleChange = (e) => {
    updateFormData({
      ...formData,
      [e.target.name]: e.target.value.trim(),
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    var form_data = new FormData();

    for (var key in formData) {
      form_data.append(key, formData[key]);
      if (key == "salary") {
        form_data.append(key, formData.salary._id);
      }
    }

    if (formData._id) {
      axios
        .post(
          "http://localhost:5000/api/user/edit/" + formData._id,
          form_data,
          {
            "content-type": "multipart/form-data",
          }
        )
        .then((res) => {
          dispatch(edituser(res.data));
          changeState();
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      form_data.append("photo", selectedFile);
      axios
        .post("http://localhost:5000/api/user/add", form_data, {
          "content-type": "multipart/form-data",
        })
        .then((res) => {
          dispatch(adduser(res.data));
          changeState();
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };

  return (
    <React.Fragment>
      <Navigation changeState={changeState} csvData={store} />
      <MainTable
        populateEditForm={populateEditForm}
        deleteHandler={deleteHandler}
      />
      <Modal size="lg" show={modalstate}>
        <Modal.Header closeButton onClick={() => changeState()}>
          <Modal.Title>Add User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <input
              type="hidden"
              name="record_id"
              id="record_id"
              value={formData._id}
            />
            <Form.Row>
              <Form.Group as={Col}>
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group as={Col}>
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </Form.Group>
            </Form.Row>

            <Form.Row>
              <Form.Group as={Col}>
                <Form.Label>Phone</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group as={Col}>
                <Form.Label>Gender</Form.Label>
                <Form.Control
                  as="select"
                  defaultValue="Male"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </Form.Control>
              </Form.Group>
            </Form.Row>

            <Form.Row>
              <Form.Group as={Col}>
                <Form.Label>Status</Form.Label>
                <Form.Control
                  as="select"
                  defaultValue="Active"
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </Form.Control>
              </Form.Group>

              <Form.Group as={Col}>
                <Form.Label>Role</Form.Label>
                <Form.Control
                  as="select"
                  defaultValue="Publisher"
                  name="role"
                  value={formData.role}
                  onChange={handleChange}
                >
                  <option value="Admin">Admin</option>
                  <option value="Publisher">Publisher</option>
                  <option value="Reviewer">Reviewer</option>
                  <option value="Moderator">Moderator</option>
                </Form.Control>
              </Form.Group>
            </Form.Row>

            <Form.Group controlId="formGridAddress1">
              <Form.Label>Address</Form.Label>
              <Form.Control
                placeholder="1234 Main St"
                name="address"
                value={formData.address}
                onChange={handleChange}
              />
            </Form.Group>

            <Form.Row>
              <Form.Group as={Col}>
                <Form.Label>Salary</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="salary"
                  name="basic_salary"
                  value={formData.basic_salary}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group as={Col}>
                <Form.Label>Bonus</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="bonus"
                  name="bonus"
                  value={formData.bonus}
                  onChange={handleChange}
                />
              </Form.Group>
            </Form.Row>
            {!formData._id ? (
              <Form.Row>
                <Form.Group>
                  <Form.File
                    id="user_profile_pic"
                    label="Profile Photo"
                    name="photo"
                    onChange={(e) => setSelectedFile(e.target.files[0])}
                  />
                </Form.Group>
              </Form.Row>
            ) : (
              <img
                src={"http://localhost:5000/uploads/" + formData.photo}
                style={{ width: 150 }}
              />
            )}

            <Form.Row>
              <Form.Group>
                <Button variant="primary" onClick={handleSubmit}>
                  Submit
                </Button>
              </Form.Group>
            </Form.Row>
          </Form>
        </Modal.Body>
      </Modal>
    </React.Fragment>
  );
};

export default MainContainer;
