const express = require("express");
const router = express.Router();
const ValidateUserInput = require("../validator/userValidator");
const User = require("../models/userModel");
const Salary = require("../models/salaryModel");
const isEmpty = require("../validator/is-empty");
var fs = require("fs");
const multer = require("multer");
const path = require("path");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

router.get("/", function (req, res) {
  User.find()
    .sort({ date: -1 })
    .populate("salary")
    .exec()
    .then((user) => {
      if (user.length == 0) {
        return res.json({ success: true, message: "No user's available." });
      } else {
        res.json(user);
      }
    })
    .catch((err) => {
      console.log(err);
    });
});

router.post("/add", upload.single("photo"), (req, res) => {
  var { errors } = ValidateUserInput(req.body);

  if (!isEmpty(errors)) {
    return res.status(400).json(errors);
  }
  // SET STORAGE
  let newUser = new User({
    name: req.body.name,
    email: req.body.email,
    phone: req.body.phone,
    address: req.body.address,
    gender: req.body.gender,
    status: req.body.status,
    role: req.body.role,
    photo: req.file.filename,
  });
  newUser
    .save()
    .then((user) => {
      newUser = user;
      const userSalary = new Salary({
        user_id: user._id,
        basic_salary: req.body.basic_salary,
        bonus: req.body.bonus,
      });
      userSalary
        .save()
        .then((salary) => {
          User.findOne({ _id: user._id }).then((user) => {
            user.salary = userSalary;
            user.save();
          });

          return res.json(newUser);
        })
        .catch((err) => {
          newUser.remove();
        });
    })
    .catch((err) => console.log(err));
});

router.post("/edit/:id", upload.none(), function (req, res) {
  var { errors } = ValidateUserInput(req.body);

  if (!isEmpty(errors)) {
    return res.status(400).json(errors);
  }
  const userFields = {
    name: req.body.name,
    email: req.body.email,
    phone: req.body.phone,
    address: req.body.address,
    gender: req.body.gender,
    status: req.body.status,
    role: req.body.role,
  };

  const salaryFields = {
    basic_salary: req.body.basic_salary,
    bonus: req.body.bonus,
  };

  User.findByIdAndUpdate(req.params.id, { $set: userFields }, { new: true })
    .then((user) => {
      Salary.findByIdAndUpdate(
        req.body.salary[1],
        { $set: salaryFields },
        { new: true }
      )
        .then((salary) => {
          user.salary = salary;
          user.save();
          return res.json(user);
        })
        .catch((err) => {
          console.log(err);
        });
    })
    .catch((err) => {
      res.status(404).json({ nouserfound: "No user found with that ID" });
    });
});

router.delete("/delete/:id", function (req, res) {
  User.findById(req.params.id)
    .then((user) => {
      Salary.findByIdAndRemove(user.salary, (error, data) => {
        if (error) {
          throw error;
        } else {
          user.remove().then(() => res.json({ success: true }));
        }
      });
    })
    .catch((err) => {
      res.status(404).json({ nouserfound: "No user found with that ID" });
    });
});

router.get("/edit/:id", function (req, res) {
  User.findById(req.params.id)
    .then((user) => {
      if (user.length == 0) {
        return res.json({ success: true, message: "No user's available." });
      } else {
        Salary.findById(user.salary, (error, data) => {
          if (error) {
            throw error;
          } else {
            user.salary = data;
            res.json(user);
          }
        });
      }
    })
    .catch((err) => {
      console.log(err);
    });
});

module.exports = router;
