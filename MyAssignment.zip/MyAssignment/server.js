const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const userRoute = require("./routes/userRouter");
const cors = require("cors");
const app = express();
global.__basedir = __dirname;

//connect database
mongoose
  .connect("mongodb://localhost/MyAssignment", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
    useCreateIndex: true,
  })
  .then((con) => {
    console.log("DB connected successfully.");
  })
  .catch((err) => {
    console.log(err);
  });

// to allow cross origin
app.use(cors());

app.use("/uploads", express.static("uploads"));

// parse application/json
app.use(bodyParser.json());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/api/user", userRoute);

const port = process.env.port || 5000;
app.listen(port, () => console.log(`server is listing on port ${port}`));
